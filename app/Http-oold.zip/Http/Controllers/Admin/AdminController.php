<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Visitor;
use App\Models\Role;
use Auth;
use App\Models\Service;
use App\Models\Contact;
use App\Models\Course;
use App\Models\Diploma;

class AdminController extends Controller
{
    public function __construct()
    {
        $this->middleware('permission:dashboard-read', ['only' => ['index']]);
  
    }

    public function index(){
        $users =User::get()->count();
        return view('admin.index',compact('users'));
    }

   
}
