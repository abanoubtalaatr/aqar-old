<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Info;
use App\Http\Requests\Admin\InfoRequest;

class SettingController extends Controller
{
  public function __construct()
    {
        $this->middleware('permission:settings-update')->only('edit','update');
    }

  public function edit()
  {
    $info = Info::first();
    return view('admin.setting.info', compact('info'));
  }

  public function update(InfoRequest $request)
  {
    $info = Info::first();
    $data = $request->input();

    if ($request->hasFile('logo')) {
      $this->remove_file($info->logo);
      $data['logo'] = $this->upload_file($request['logo'], 'infos');
    }
    if ($request->hasFile('logo_footer')) {
      $this->remove_file($info->logo_footer);
      $data['logo_footer'] = $this->upload_file($request['logo_footer'], 'infos');
    }
    if ($request->hasFile('icon')) {
      $this->remove_file($info->icon);
      $data['icon']  = $this->upload_file($request['icon'], 'infos');
    }
    if ($request->hasFile('bank_qr_image')) {
      $this->remove_file($info->bank_qr_image);
      $data['bank_qr_image']  = $this->upload_file($request['bank_qr_image'], 'infos');
    }

    $info->update($data);
    return redirect('setting/info')->with(["success" => __('dashboard.recored updated successfully.')]);
  }
  
}
