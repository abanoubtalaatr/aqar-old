<?php

namespace App\Http\Controllers\Admin;

use App\Models\City;
use App\Models\Neighborhood;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\NeighborhoodRequest;

class NeighborhoodController extends Controller
{
    public function __construct()
    {
        $this->middleware('permission:neighborhoods-read')->only('index', 'show');
        $this->middleware('permission:neighborhoods-create')->only('create', 'store');
        $this->middleware('permission:neighborhoods-update')->only('edit', 'update');
        $this->middleware('permission:neighborhoods-delete')->only('destroy');
    }

    public function index(Request $request)
    {
        $city = City::find($request->city_id);
        $neighborhoods = Neighborhood::where('city_id', $request->city_id)->paginate(20);
        // dd($neighborhoods);
        return view('admin.neighborhoods.index', compact('neighborhoods', 'city'));
    }

    public function create(Request $request)
    {
        $city_id = $request->city_id;
        // dd($city_id);
        $cities = Neighborhood::get();
        return view('admin.neighborhoods.create', compact('cities', 'city_id'));
    }

    public function store(NeighborhoodRequest $request)
    {
        // dd($request->validated());
        Neighborhood::create($request->validated());
        return to_route('neighborhoods.index', ['city_id' => $request->city_id])->with(["success" => __('dashboard.recored created successfully.')]);
    }


    public function edit(Neighborhood $neighborhood)
    {
        $neighborhoods = Neighborhood::get();
        return view('admin.neighborhoods.update', compact('neighborhoods', 'neighborhood'));
    }


    public function update(NeighborhoodRequest $request, Neighborhood $neighborhood)
    {

        $neighborhood->update($request->validated());
        return to_route('neighborhoods.index', ['city_id' => $neighborhood->city_id])->with(["success" => __('dashboard.recored updated successfully.')]);
    }


    public function destroy($id)
    {
        $city = Neighborhood::find($id)->delete();
        return "success";
    }

    //=========================delete all==================
    public function delete_all(Request $request)
    {
        Neighborhood::whereIn('id', $request['ids'])->delete();
        return "success";
    }
}
