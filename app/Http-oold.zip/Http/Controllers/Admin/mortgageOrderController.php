<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\MortgageOrder;
use Illuminate\Http\Request;

class MortgageOrderController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $mortgages = MortgageOrder::paginate(15);
        MortgageOrder::where('seen',0)->update(['seen' => 1]);
        return view('admin.Mortgage_orders.index', compact('mortgages'));
    }

    /**
     * Show the form for creating a new resource.
     */

    public function show(MortgageOrder $MortgageOrder)
    {
        //
        return view('admin.Mortgage_orders.show', compact('MortgageOrder'));

    }

    /**
     * Show the form for editing the specified resource.
     */
}