<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\admin\BlogRequest;
use App\Models\Blog;
use App\Models\City;
use App\Models\Country;
use App\Models\Neighborhood;
use Illuminate\Http\Request;

class BlogController extends Controller
{
    public function __construct()
    {
        $this->middleware('permission:blogs-read')->only('index', 'show');
        $this->middleware('permission:blogs-create')->only('create', 'store');
        $this->middleware('permission:blogs-update')->only('edit', 'update');
        $this->middleware('permission:blogs-delete')->only('destroy');
    }
    public function index()
    {

        $blogs = Blog::orderBy('created_at', 'desc')->paginate(15);
        return view('admin.blogs.index', compact('blogs'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $neighborhoods = Neighborhood::all();
        return view('admin.blogs.create', compact('neighborhoods'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(BlogRequest $request)
    {

        $data = $request->validated();
        if ($request->hasFile('image')) {
            $data['image'] = $this->upload_file($request['image'], 'blogs');
        }
        Blog::create($data);
        return to_route('blogs.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(Blog $blog)
    {

        $neighborhoods = Neighborhood::all();
        return view('admin.blogs.show', compact('blog', 'neighborhoods'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Blog $blog)
    {

        $neighborhoods = Neighborhood::all();
        return view('admin.blogs.update', compact('neighborhoods', 'blog'));
    }


    public function update(BlogRequest $request, Blog $blog)
    {
        $data = $request->validated();
        if ($request->hasFile('image')) {
            $blog->image ? $this->remove_file($blog->image) : '';
            $data['image'] = $this->upload_file($request['image'], 'blogs');
        }

        $blog->update($data);
        return to_route('blogs.index');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Blog $blog)
    {
        $blog->image ? $this->remove_file($blog->image) : '';
        $blog->delete();
        return "success";
    }
    public function delete_all(Request $request)
    {
        $icons = Blog::whereIn('id', $request['ids'])->pluck('image');
        $this->remove_all($icons);
        blog::whereIn('id', $request['ids'])->delete();
        return "success";
    }
}
