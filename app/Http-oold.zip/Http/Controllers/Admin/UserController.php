<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Http\Requests\Admin\UserRequest;
use Illuminate\Support\Facades\Hash;
use App\Models\Role;
use App\Notifications\ActiveUserNotification;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
    public function __construct()
    {
        $this->middleware('permission:users-read')->only('index', 'show');
        $this->middleware('permission:users-create')->only('create', 'store');
        $this->middleware('permission:users-update')->only('edit','update');
        $this->middleware('permission:users-delete')->only('destroy','delete_all','active');
    }
  
    public function index()
    {

        $users = User::paginate(20);

        return view('admin.users.index', compact('users'));
    }

  
    public function create()
    {
        $roles = Role::get();
        return view('admin.users.create', compact('roles'));
    }

   
    public function store(UserRequest $request)
    {
        if ($request->hasFile('avatar')) {
            $avatar = $this->upload_file($request['avatar'], 'users');
        }

        $data = array_merge($request->except('password_confirmation', 'role'), ["avatar" => $avatar ?? null]);
        $user = User::create($data);
        if ($request->role !== null) {
            $role = Role::where('name', $request['role'])->first();
            $role ? $user->addRole($role) : '';
        }
        return to_route('users.index')->with(["success" => __('dashboard.recored created successfully.')]);
    }

    public function show(User $user)
    {
        if (request()->has('not')) {
            $not = Auth::user()->unreadNotifications->where('id', request('not'))->first();
            if ($not) {
                $not->markAsRead();
            }
        }
        return view('admin.users.show', compact('user'));
    }

   
    public function edit(User $user)
    {
        $roles = Role::get();
        return view('admin.users.update', compact('user', 'roles'));
    }

   
    public function update(UserRequest $request, User $user)
    {


        if ($request->hasFile('avatar')) {
            $user->avatar ? $this->remove_file($user->avatar) : '';
            $avatar = $this->upload_file($request['avatar'], 'users');
        }

        $data = array_merge($request->except(['user_id', 'password_confirmation', 'role']), ["avatar" => $avatar ?? $user->avatar]);
        $user->update($data);

        if (!$user->hasRole('super_admin')) {
            foreach ($user->roles as $role) {
                $user->removeRole($role);
            }
            $role = Role::find($request['role']);
            $role ? $user->addRole($role) : '';
        }

        return to_route('users.index')->with(["success" => __('dashboard.recored updated successfully.')]);
    }

   
    public function destroy($id)
    {
        $user = User::find($id);
        $user->avatar ? $this->remove_file($user->avatar) : '';
        $user->delete();
        return $id;
    }

    //=========================delete all==================
    public function delete_all(Request $request)
    {

        $icons = User::whereIn('id', $request['ids'])->pluck('avatar');
        $this->remove_all($icons);
        User::whereIn('id', $request['ids'])->delete();
        return "success";
    }

    //========================active=========================
    public function active($id)
    {
        $user = User::find($id);
        if ($user->active == 0) {
            $user->active = 1;
            $user->reason_unactivate = null;
        } else {
            $user->active = 0;
            $user->reason_unactivate = request('reason') ?? null;
        }
        $user->save();
        $user->notify(new ActiveUserNotification($user->active));
        return "success";
    }
}
