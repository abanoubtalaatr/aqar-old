<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\PartnerRequest;
use App\Models\Partner;
use Illuminate\Http\Request;

class PartnerController extends Controller
{

  public function __construct()
  {
    $this->middleware('permission:partners-read')->only('index', 'show');
    $this->middleware('permission:partners-create')->only('create', 'store');
    $this->middleware('permission:partners-update')->only('edit', 'update');
    $this->middleware('permission:partners-delete')->only('destroy');
  }

  public function index()
  {
    $partners = Partner::paginate(10);
    return view('admin.partners.index', compact('partners'));
  }

  public function create()
  {
    return view('admin.partners.create');
  }

  public function store(PartnerRequest $request)
  {
    if ($request->hasFile('image')) {
      $image = $this->upload_file($request['image'], 'partners');
    }
    Partner::create(['image' => $image]);
    return to_route('partners.index')->with(["success" => __('site.recored created successfully.')]);
  }



  public function edit(Partner $partner)
  {
    return view('admin.partners.update', compact('partner'));
  }

  public function update(PartnerRequest $request, Partner $partner)
  {
    if ($request->hasFile('image')) {
      $partner->image ? $this->remove_file($partner->image) : '';
      $image = $this->upload_file($request['image'], 'partners');
    }
    $partner->update(['image' => $image]);
    return redirect('partners')->with(["success" => __('site.recored updated successfully.')]);
  }

  public function destroy(Partner $partner)
  {
    $partner->image ? $this->remove_file($partner->image) : '';
    $partner->delete();
  }

  //=========================delete all==================
  public function delete_all(Request $request)
  {
    $icons = Partner::whereIn('id', $request['ids'])->pluck('image');
    $this->remove_all($icons);
    Partner::whereIn('id', $request['ids'])->delete();
    return "success";
  }
}
