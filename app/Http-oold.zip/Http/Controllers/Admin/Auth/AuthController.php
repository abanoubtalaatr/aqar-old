<?php

namespace App\Http\Controllers\Admin\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\LoginRequest;
use Illuminate\Http\Request;

class AuthController extends Controller
{

    public function __construct()
    {

    }

    public function showLoginForm()
    {
        return view('admin.auth.login');
    }

    public function login(LoginRequest $request)
    {
        $credentials = $request->validated();
        $credentials['is_active'] = true;
        $rememberMe = $request->remember_me == 'on';
        if (auth()->attempt($credentials, $rememberMe)) {
            return redirect()->route('admin');
        } else {
            return redirect()->route('auth.login')->with(['error' => __('messages.Incorrect email or password')]);
        }
    }

    public function logout()
    {
        auth()->logout();
        return redirect()->route('auth.login');
    }
}
