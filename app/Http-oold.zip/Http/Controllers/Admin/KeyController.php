<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\KeyRequest;
use App\Models\Choice;
use App\Models\Key;
use Illuminate\Http\Request;

class KeyController extends Controller
{
    public function __construct()
    {
        $this->middleware('permission:keys-read')->only('index', 'show');
        $this->middleware('permission:keys-create')->only('create', 'store');
        $this->middleware('permission:keys-update')->only('edit', 'update');
        $this->middleware('permission:keys-delete')->only('destroy');
    }
    public function index($category_id)
    {
        $keys = Key::where('category_id', $category_id)->paginate(20);
        return view('admin.keys.index', compact('keys', 'category_id'));
    }

    public function create($category_id)
    {

        return view('admin.keys.create', compact('category_id'));
    }

    public function store(KeyRequest $request)
    {
        $key = Key::create($request->except('choices'));
        if ($request->has('choices')) {
            $key->choices()->createMany($request->choices);
        }
        return redirect()->route('keys.index', ['category_id' => $key->category_id])->with(["success" => __('dashboard.recored_created_successfully')]);
    }

    public function edit(Key $key)
    {
        return view('admin.keys.update', compact('key'));
    }

    public function update(KeyRequest $request, Key $key)
    {
        $key->update($request->except('choices'));

        //delete 
        $choiceIdsInRequest = collect($request->choices)->pluck('id')->filter();
        $key->choices()->whereNotIn('id', $choiceIdsInRequest)->delete();

        //create & update 
        if ($request->has('choices')) {
            foreach ($request->choices as $i => $choice) {
                $id = isset($request->choices[$i]['id']) ?? null;
                Choice::updateOrCreate(
                    ['id' => $id],
                    [
                        'key_id' => $key->id,
                        'value_ar' => $request->choices[$i]['value_ar'],
                        'value_en' => $request->choices[$i]['value_en']
                    ]
                );
            }
        }
        return redirect()->route('keys.index', ['category_id' => $key->category_id])->with(["success" => __('dashboard.updated_successfulley')]);
    }


    public function destroy($id)
    {
        $key = Key::find($id);
        $key->delete();
        return $id;
    }
}
