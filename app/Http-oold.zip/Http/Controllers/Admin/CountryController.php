<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\CountryRequest;
use App\Models\Country;
use Illuminate\Http\Request;

class CountryController extends Controller
{
 
    public function __construct()
    {
        $this->middleware('permission:countries-read')->only('index', 'show');
        $this->middleware('permission:countries-create')->only('create', 'store');
        $this->middleware('permission:countries-update')->only('edit','update');
        $this->middleware('permission:countries-delete')->only('destroy');
    }

    public function index(){
        $countries = Country::paginate(20);
        return view('admin.countries.index',compact('countries'));
    }

    public function create()
    {
        return view('admin.countries.create');
    }

    public function store(CountryRequest $request)
    {
        Country::create($request->input());
        return to_route('countries.index')->with(["success" => __('dashboard.recored created successfully.')]);
    }


    public function edit(Country $country)
    {
        return view('admin.countries.update', compact('country'));
    }


    public function update(CountryRequest $request, Country $country)
    {

        $country->update($request->input());
        return to_route('countries.index')->with(["success" => __('dashboard.recored updated successfully.')]);
    }


    public function destroy($id)
    {
        $country = Country::find($id)->delete();
        return "success";
    }

    //=========================delete all==================
    public function delete_all(Request $request)
    {
        Country::whereIn('id', $request['ids'])->delete();
        return "success";
    }
}
