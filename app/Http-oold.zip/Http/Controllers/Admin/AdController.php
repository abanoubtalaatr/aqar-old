<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Resources\AdableResource;
use App\Models\Ad;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Notification;

class AdController extends Controller
{

    public function __construct()
    {
        $this->middleware('permission:ads-read', ['only' => ['index', 'show']]);
        $this->middleware('permission:ads-delete', ['only' => ['changeActiveDefaultValue', 'active', 'destroy', 'delete_all']]);
    }

    public function index()
    {
        $ads = Ad::orderBy('created_at', 'desc')->paginate(15);

        return view('admin.ads.index', compact('ads'));
    }

    public function show($id)
    {
        $ad = Ad::find($id);
        $files = $ad->files;
        $allowedImageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'svg', 'ico', 'tif', 'tiff'];
        $allowedVideoExtensions = ['mp4', 'avi', 'mov', 'mkv', 'wmv', 'flv', 'webm', 'mpeg', 'mpg', '3gp'];
        $images = null;
        $viedeos = null;
        $adable = $ad->adable_type::find($ad->adable_id)->toArray();

        foreach ($files as $file) {
            if (in_array(strtolower(pathinfo($file->path, PATHINFO_EXTENSION)), $allowedImageExtensions)) {
                $images[] = url('') . '/' . $file->path;
            } elseif (in_array(strtolower(pathinfo($file->path, PATHINFO_EXTENSION)), $allowedVideoExtensions)) {
                $viedeos[] = url('') . '/' . $file->path;
            }
        }
        return view('admin.ads.show', compact('ad', 'images', 'viedeos', 'adable'));
    }
    public function markasread($id)
    {
        $user = User::find(auth()->user()->id);
        $noti = $user->unreadnotifications()->where('id', $id)->first();
        $noti->markAsRead();
        $ad = Ad::find($noti->data['ad_id']);
        $adable = $ad->adable_type::find($ad->adable_id)->toArray();
        $files = $ad->files;
        $allowedImageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'svg', 'ico', 'tif', 'tiff'];
        $allowedVideoExtensions = ['mp4', 'avi', 'mov', 'mkv', 'wmv', 'flv', 'webm', 'mpeg', 'mpg', '3gp'];
        $images = null;
        $viedeos = null;
        foreach ($files as $file) {
            if (in_array(strtolower(pathinfo($file->path, PATHINFO_EXTENSION)), $allowedImageExtensions)) {
                $images[] = url('') . '/' . $file->path;
            } elseif (in_array(strtolower(pathinfo($file->path, PATHINFO_EXTENSION)), $allowedVideoExtensions)) {
                $viedeos[] = url('') . '/' . $file->path;
            }
        }
        return view('admin.ads.show', compact('ad', 'adable', 'images', 'viedeos'));
    }
    public function destroy($id)
    {
        $ad = Ad::find($id);
        foreach ($ad->files as $i) {
            $file = $this->remove_file($i->path);
        }
        $ad->delete();
        return $id;
    }

    //=========================delete all==================
    public function delete_all(Request $request)
    {
        foreach ($request['ids'] as $id) {
            $files = Ad::find($id)->files->pluck('path');
            $this->remove_all($files);
        }
        Ad::whereIn('id', $request['ids'])->delete();
        return "success";
    }

    //========================active=========================
    public function active($id)
    {
        $Ad = Ad::find($id);
        if ($Ad->is_active == 0) {
            $Ad->is_active = 1;
        } else {
            $Ad->is_active = 0;
        }
        $Ad->save();
        return "success";
    }
    //========================star=========================
    public function star($id)
    {
        $Ad = Ad::find($id);
        if ($Ad->stared == 0) {
            $Ad->stared = 1;
        } else {
            $Ad->stared = 0;
        }
        $Ad->save();
        return "success";
    }
}
