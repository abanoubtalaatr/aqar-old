<?php

namespace App\Http\Controllers\Api\Web;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\Web\MortgageOrderRequest;
use App\Models\MortgageOrder;
use Illuminate\Http\Request;
use App\Traits\GeneralTrait;

class MortgageOrderController extends Controller
{
    use GeneralTrait;
    public function store(MortgageOrderRequest $request)
    {
        // return $request ;
        MortgageOrder::create($request->validated());
       
        return $this->returnSuccessMassage('success');
    }
}
