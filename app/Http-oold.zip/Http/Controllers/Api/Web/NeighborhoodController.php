<?php

namespace App\Http\Controllers\Api\Web;

use App\Models\City;
use App\Models\Neighborhood;
use App\Traits\GeneralTrait;
// use App\Http\Resources\web\NeighborhoodResource;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Resources\Web\NeighborhoodResource;

class NeighborhoodController extends Controller
{
    use GeneralTrait;

    public function index($city_id)
    
    { 

        $city = City::find($city_id);
        // return $this->returnData('data', $city);
        if ($city) {
            $neighborhood = $city->neighborhoods;
            $neighborhood_data = NeighborhoodResource::collection($neighborhood);
            return $this->returnData('data', $neighborhood_data);
        } else {
            return $this->returnError('404', __('site.not found.'));
        }
    }
}
