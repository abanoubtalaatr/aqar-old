<?php

namespace App\Http\Controllers\Api\Web;

use App\Http\Controllers\Controller;
use App\Http\Resources\Web\CityResource;
use App\Models\City;
use App\Models\Country;
use App\Traits\GeneralTrait;
use Illuminate\Http\Request;

class CityController extends Controller
{
    use GeneralTrait;

    public function index($country_id)
    {
        $country= Country::find($country_id);
        if($country){
            $cities = $country->cities;
            $cities_data = CityResource::collection($cities);
            return $this->returnData('data', $cities_data);
        }else{
            return $this->returnError('404',__('site.not found.'));
        }
       
    }
    public function allCities()
    {
            $cities = City::all();
            $cities_data = CityResource::collection($cities);
            return $this->returnData('data', $cities_data);
       
    }
}
