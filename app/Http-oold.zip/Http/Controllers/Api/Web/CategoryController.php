<?php

namespace App\Http\Controllers\Api\Web;

use App\Http\Controllers\Controller;
use App\Http\Resources\Web\AdditionalKeyResource;
use App\Http\Resources\Web\CategoryResource;
use App\Http\Resources\Web\KeyResource;
use App\Http\Resources\Web\StaticKeyResource;
use App\Models\Category;
use App\Traits\GeneralTrait;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    use GeneralTrait;
    
    public function index()
    {
        $categories = Category::get();
        $categories = CategoryResource::collection($categories);
        return $categories;
    }

    public function getCategoryKeys($id)
    {
        $category = Category::find($id);
        if ($category) {
            $keys = KeyResource::collection($category->keys);
            return $this->returnData('data', $keys);
        } else {
            return $this->returnError('404', 'not found');
        }
    }
    public function getCategoryKeysForOrders($id)
    {
        $category = Category::find($id);
        if ($category) {
            $keys = KeyResource::collection($category->keys->where('show_in_order', 1));
            return $this->returnData('data', $keys);
        } else {
            return $this->returnError('404', 'not found');
        }
    }
}
