<?php

namespace App\Http\Controllers\Api\Web;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\ContactRequest;
use App\Http\Resources\Web\CategoryResource;
use App\Http\Resources\Web\InfoResource;
use App\Http\Resources\Web\PartnerResource;
use App\Models\Category;
use App\Models\Contact;
use App\Models\Info;
use App\Models\Page;
use App\Models\Partner;
use App\Traits\GeneralTrait;
use Illuminate\Http\Request;

class SettingController extends Controller
{
    use GeneralTrait;

    public function info()
    {
        $info = Info::first();
        $info = new InfoResource($info);
        return $this->returnData('data',  $info);
    }
    public function partners()
    {
        $partners = Partner::get();
        $partners_data =  PartnerResource::collection($partners);
        return $this->returnData('data', $partners_data);
    }


    public function contact(ContactRequest $request)
    {
        // return "d";
        // return $request ;
        $contact = Contact::create($request->input());
        $this->send_notii('contactNotification', $contact, 'browse_contact', $request['name']);
        return $this->returnSuccessMassage(__('api.Sent Successfully'), 201);
    }
}
