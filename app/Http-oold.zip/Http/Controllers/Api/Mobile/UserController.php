<?php

namespace App\Http\Controllers\Api\Mobile;

use App\Models\PasswordReset;
use App\Models\User;
use Illuminate\Support\Facades\Mail;
use Tymon\JWTAuth\Facades\JWTAuth;
use App\Http\Controllers\Controller;
use App\Http\Requests\Api\UpdatePasswordRequest;
use App\Http\Requests\Api\Mobile\UpdateProfileRequest;
use App\Http\Requests\Api\UserResetPasswordRequest;
use App\Http\Requests\Api\UserResetPasswordRequest2;
use App\Http\Requests\Api\UserResetPasswordRequest3;
use App\Http\Resources\Mobile\ProfileResource;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use App\Traits\GeneralTrait;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{

    use GeneralTrait;

    public function profile()
    {

        $user = new ProfileResource(JWTAuth::user());
        // $user_ads = AdProfileResource::collection(JWTAuth::user()->ads()->orderBy('created_at', 'desc')->paginate(5))->response()->getData(true);
        // $followers = User::find(JWTAuth::user()->id)->followers;
        // $followers = UserResource::collection($followers);
        return $this->returnData(
            'data',
            ['profile' => $user]
        );
    }

    public function updateProfile(UpdateProfileRequest $request)
    {
        $data = $request->validated();
        $user = User::where('id', JWTAuth::user()->id)->first();
        if ($request->hasFile('avatar')) {
            $user->avatar ? $this->remove_file($user->avatar) : '';
            $data['avatar'] = $this->upload_file($request['avatar'], 'users');
        }
        $user->update($data);
        return $this->returnSuccessMassage(__('تم التحديث بنجاح'));
    }

    

   

   

}
