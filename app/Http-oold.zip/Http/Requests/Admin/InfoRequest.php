<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Request;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;

class InfoRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name_ar' => 'required',
            'name_en' => 'required',
            'logo' => 'nullable|mimes:jpeg,png,jpg,gif,svg,webp',
            'logo_footer' => 'nullable|mimes:jpeg,png,jpg,gif,svg,webp',
            'icon' => 'nullable|mimes:jpeg,png,jpg,gif,svg,webp',
            'email' => 'required',
            'phone' => 'required',
            'whatsapp_phone' => 'required',
            'fb' => 'required',
            'tw' => 'required',
            'inst' => 'required',
            'linkedin' => 'required',
            'snapchat' => 'required',
            'slogan_ar' => 'required',
            'slogan_en' => 'required',
            'copy_right_ar' => 'required',
            'copy_right_en' => 'required',
            'bank_account_num' => 'required',
            'bank_iban_num' => 'required',
            'bank_qr_image' => 'nullable|mimes:jpeg,png,jpg,gif,svg,webp',
            'ad_active_default_value' => 'required|in:0,1',
        ];
    }



    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(redirect()->back()->withErrors($validator->errors())->withInput());
    }
}
