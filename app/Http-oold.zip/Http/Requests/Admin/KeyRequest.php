<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Request;

class KeyRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    public function rules(Request $request)
    {
        return [
            'category_id' => $request->method() == 'POST' ? 'required|exists:categories,id' : '',
            'name_ar' => 'required|string',
            'name_en' => 'required|string',
            'type' => 'required|in:text,textarea,number,number_with_select,range,checkbox,select,radio,',
            'is_required' => 'required|in:0,1',
            // 'choices' => 'required_if:type,select,radio|array',
            // 'choices.*'
        ];
    }
}
