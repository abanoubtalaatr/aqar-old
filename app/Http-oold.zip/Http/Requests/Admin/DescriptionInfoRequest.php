<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Request;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;
class DescriptionInfoRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            
                'desc_image1'=>'nullable|mimes:jpeg,png,jpg,gif,svg',
                'hint1_ar'=>'nullable|string',
                'hint1_en'=>'nullable|string',
                'short_description1_ar' =>'nullable|string',
                'short_description1_en' =>'nullable|string',

                'hint2_ar'=>'nullable|string',
                'hint2_en'=>'nullable|string',
                'short_description2_ar' =>'nullable|string',
                'short_description2_en' =>'nullable|string',
                'desc_image2'=>'nullable|mimes:jpeg,png,jpg,gif,svg',

        ];
    }


    


    protected function failedValidation(Validator $validator) {
            throw new HttpResponseException(redirect()->back()->withErrors($validator->errors())->withInput());
     }
}
