<?php

namespace App\Http\Requests\Api\Mobile;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use App\Traits\GeneralTrait;
use Illuminate\Http\Exceptions\HttpResponseException;

class UpdateAdRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'for_rent' => 'nullable|in:0,1',
            'category_id' => 'nullable|exists:categories,id',
            'license_number' => 'nullable',
            'price' => 'nullable|integer',
            'currency_id' => 'nullable|exists:currencies,id',
            'area' => 'nullable|integer',
            'length' => 'nullable|integer',
            'width' => 'nullable|integer',
            'advertiser_relationship_with_property' => 'nullable|in:0,1,2',
            'description' => 'nullable|string',
            'map_latitude' => 'nullable',
            'map_longitude' => 'nullable',
            'files' => 'nullable|array' ,
        ];
    }
    protected function failedValidation(Validator $validator) {
        throw new HttpResponseException( $this->returnValidationError(400, $validator));
    }
}
