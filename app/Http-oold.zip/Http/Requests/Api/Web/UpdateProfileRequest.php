<?php

namespace App\Http\Requests\Api\Web;

use Illuminate\Foundation\Http\FormRequest;
use Tymon\JWTAuth\Facades\JWTAuth;
use Tymon\JWTAuth\JWT;

class UpdateProfileRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $user = JWTAuth::user();
        return [
            'avatar' => 'nullable|image',
            'name' => "nullable|string",
            'email' => "nullable|email|unique:users,email,except,$user->email",
            'about' => "nullable|string",
            'membership_type' => "nullable|numeric",
            'phone' => "nullable|unique:users,phone,except,$user->phone",
            'password' => "nullable|min:8",
            'marketing_license' => "nullable|url",
        ];
    }
}
