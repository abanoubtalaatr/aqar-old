<?php

namespace App\Http\Resources\web;

use App\Models\Key;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class WarehousesResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $data = [];
        $keys = Key::where('category_id', Category::where('key', 'warehouse')->first()->id)->get();
       foreach ($keys as $key) {
            if($key->name!= 'property_age'){
            array_push($data, ['attribute_name' => $key->name, 'attribute_value' => $this->{$key->attribute_name}]);
            }
        }
        return $data;
        // return [
        //     'interface' => $this->interface,
        //     "street_width" => $this->street_width,
        //     "property_age" => $this->property_age,
        // ];
    }
}
