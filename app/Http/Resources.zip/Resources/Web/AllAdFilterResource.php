<?php

namespace App\Http\Resources\web;

use App\Models\Ad;
use App\Models\Key;
use App\Models\Category;
use App\Models\City;
use App\Models\Neighborhood;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class AllAdFilterResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request)
    {

        $data = [];
        $ads = Ad::where('category_id', $this->category_id)->where('for_rent', $this->for_rent)->get();
        $neighborhoods= Neighborhood::all();
        // return $neighborhoods;
        foreach ($neighborhoods as $neighborhood) {

            array_push($data, [
                'name' => optional($this->category)->name .  $this->for_rent_val . __('dashboard.in')  . $neighborhood->name . ' ' . __('dashboard.in') . optional($neighborhood->city)->name,
                'neighborhood_id' => $neighborhood->id,
                'category_id' => $this->category_id,
                'similar_ads_number' => Ad::where('neighborhood_id', $neighborhood->id)->where('category_id', $this->category_id)->where('for_rent', $this->for_rent)->count(),
                'for_rent' => $this->for_rent,
            ]);

        }

        return $data;
        //we want a way to make it send the data to the frontend different ways for for rent and for neighborhood_id etc 
    }
}
