<?php

namespace App\Http\Resources\Mobile;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class MapAdsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        if ($this->for_rent == 1) {
            $for_rent = $this->renting_duration;
        } else {
            $for_rent = $this->for_rent_val;
        }
        // return parent::toArray($request);
        return [
            'id' => $this->id,
            'name' => optional($this->category)->name .  $this->for_rent_val . __('dashboard.in')  . optional($this->neighborhood)->name . ' ' . __('dashboard.in') . optional($this->neighborhood->city)->name,
            'for_rent' => $for_rent,
            'ad_number' => $this->ad_number,
            'views_count' => $this->views_count,
            'is_fav' => $this->is_favourite,
            'is_active' => $this->is_active,
            'is_star' => $this->stared,
            'map_latitude' => $this->map_latitude,
            'map_longitude' => $this->map_longitude,
            'price' => $this->price,
            'currency_name' => $this->currency->name,
            'neighborhood_name' => optional($this->neighborhood)->name,
            'city_name' => optional($this->neighborhood->city)->name,
            'country_name' => optional($this->neighborhood->city->country)->name,
            'area' => $this->area,
            'length' => $this->length,
            'width' => $this->width,
            'images' => FileResource::collection($this->files->where('type', 0)),
            'videos' => FileResource::collection($this->files->where('type', 1)),

        ];
    }
}
