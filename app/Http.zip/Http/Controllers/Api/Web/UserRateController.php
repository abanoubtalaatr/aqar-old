<?php

namespace App\Http\Controllers\Api\Web;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\Web\UserRateRequest;
use App\Models\UserRate;
use App\Traits\GeneralTrait;
use Illuminate\Http\Request;
use Tymon\JWTAuth\Facades\JWTAuth;

use function PHPUnit\Framework\isEmpty;

class UserRateController extends Controller
{
    use GeneralTrait;




    public function store(UserRateRequest $request)
    {
       $rater = JWTAuth::user();
        UserRate::updateOrCreate([
            'user_id' => $request->user_id,
            'rater_id' => $rater->id,

        ], [
            'rate' => $request->rate,
        ]);
        if (UserRate::where(['rater_id' => $rater->id, 'user_id' => $request->user_id])->exists()) {
            return $this->returnSuccessMassage(__('site.recored updated successfully.'));
        } else {
            return $this->returnSuccessMassage(__('site.recored created successfully.'));
        }
    }
}
