<?php

namespace App\Http\Controllers\Api\Web;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\Web\ConstructionOrderRequest;
use App\Models\ConstructionOrder;
use GrahamCampbell\ResultType\Success;
use Illuminate\Http\Request;
use App\Traits\GeneralTrait;

class ConstructionOrderController extends Controller
{
    //
    use GeneralTrait;
    public function store(ConstructionOrderRequest $request)
    {
        if ($data = ConstructionOrder::create($request->validated())) {
            return $this->returnSuccessMassage('success');
        } else {
            return $this->returnErrorMassage('error');
        }
    }
}
