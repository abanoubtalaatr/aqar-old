<?php

namespace App\Http\Controllers\Api\Web;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Traits\GeneralTrait;
use Tymon\JWTAuth\Facades\JWTAuth;
use App\Http\Requests\Api\Web\LoginRequest;
use App\Http\Requests\Api\Web\RegisterRequest;
use App\Http\Resources\Web\LoginResource;
use App\Models\Role;

class AuthController extends Controller
{
    use GeneralTrait;

    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    public function login(LoginRequest $request)
    {
        $user = User::Where('phone', $request->phone)->first();
        // if ($user->is_active == 1) {
            $credentials = $request->only('phone', 'password');
            if (!$token = JWTAuth::attempt($credentials)) {
                return $this->returnError('401', __('بيانات خطأ'));
            }
            $user = new LoginResource(JWTAuth::user());
            return $this->returnData('data', $user);
        // } else {
        //     return $this->returnError('401', __('بيانات خطأ'));
        // }
    }

    public function logout()
    {
        $logout = auth()->guard('api')->logout();

        return $this->returnSuccessMassage(__('تم تسجيل الخروج بنجاح'));
    }

    public function register(RegisterRequest $request)
    {
        $user = User::create($request->validated());
        $credentials = $user->only(['phone', 'password']);
        $token = Auth::guard('api')->attempt($credentials); //Generate Token
        $user = new LoginResource($user);
        return $this->returnData('data', $user, __('site.successfully registered'));
    }
}
