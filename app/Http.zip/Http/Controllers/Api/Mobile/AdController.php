<?php

namespace App\Http\Controllers\Api\Mobile;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\Mobile\ReportAdRequest;
use App\Http\Requests\Api\Mobile\AdRequest;
use App\Http\Resources\Mobile\AdResource;
use App\Models\Ad;
use App\Models\AdKey;
use App\Models\Apartment;
use App\Models\Building;
use App\Models\Camp;
use App\Models\Category;
use App\Models\Chalet;
use App\Models\CommercialOffice;
use App\Models\Farm;
use App\Models\File;
use App\Models\Floor;
use App\Models\FurnishedApartment;
use App\Models\FurnishedVilla;
use App\Models\House;
use App\Models\Land;
use App\Models\Report;
use App\Models\Rest;
use App\Models\Room;
use App\Models\Shop;
use App\Models\Studio;
use App\Models\Villa;
use App\Models\Warehouse;
use App\Traits\GeneralTrait;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class AdController extends Controller
{
    use GeneralTrait;

    public function index(Request $request)
    {
        // return $request->for_rent;
        $ads = Ad::active()
            ->orderBy('created_at', 'desc')
            ->when($request->has('category_id'), function ($query) use ($request) {
                $query->where('category_id', $request->category_id);
            })
            ->when($request->has('for_rent'), function ($query) use ($request) {
                $query->where('for_rent', $request->for_rent);
            })
            ->when($request->has('neighborhood_id'), function ($query) use ($request) {
                $query->where('neighborhood_id', $request->neighborhood_id);
            })
            ->when($request->has('price_from') && $request->has('price_to'), function ($query) use ($request) {
                $query->whereBetween('price', [$request->price_from, $request->price_to]);
            })
            ->when($request->has('area_from') && $request->has('area_to'), function ($query) use ($request) {
                $query->whereBetween('area', [$request->area_from, $request->area_to]);
            })
            ->when($request->has('description'), function ($query) use ($request) {
                $query->where('description', 'LIKE', '%' . $request->description . '%');
            })
            ->when($request->has('map_latitude') && $request->has('map_longitude'), function ($query) use ($request) {
                $query->where(function ($query) use ($request) {
                    $query->orWhereBetween('map_latitude', [$request->map_latitude - 1, $request->map_latitude + 1])
                        ->orWhereBetween('map_longitude', [$request->map_longitude - 1, $request->map_longitude + 1]);
                });
            })
            ->when($request->has('renting_duration'), function ($query) use ($request) {
                $query->whereHasMorph('adable', [Apartment::class, Villa::class, Rest::class, Chalet::class], function (Builder $query) use ($request) {
                    $query->where('renting_duration', '<', $request->renting_duration);
                });
            })
            ->when($request->has('number_of_rooms'), function ($query) use ($request) {
                $query->whereHasMorph('adable', [Apartment::class, Villa::class, Floor::class, House::class, FurnishedApartment::class, FurnishedVilla::class, Studio::class], function (Builder $query) use ($request) {
                    $query->where('number_of_rooms', $request->number_of_rooms);
                });
            })
            ->when($request->has('families_or_singles'), function ($query) use ($request) {
                $query->whereHasMorph('adable', [Apartment::class, Villa::class, FurnishedApartment::class, Studio::class, Camp::class], function (Builder $query) use ($request) {
                    $query->where('families_or_singles', $request->families_or_singles);
                });
            })
            ->when($request->has('furnished'), function ($query) use ($request) {
                $query->whereHasMorph('adable', [Apartment::class, Villa::class, House::class, CommercialOffice::class, FurnishedApartment::class, FurnishedVilla::class, Studio::class], function (Builder $query) use ($request) {
                    $query->where('furnished', $request->furnished);
                });
            })
            ->when($request->has('number_of_bathrooms'), function ($query) use ($request) {
                $query->whereHasMorph('adable', [Apartment::class, Villa::class, Floor::class, FurnishedApartment::class, FurnishedVilla::class, Studio::class], function (Builder $query) use ($request) {
                    $query->where('number_of_bathrooms', $request->number_of_bathrooms);
                });
            })
            ->when($request->has('car_entrance'), function ($query) use ($request) {
                $query->whereHasMorph('adable', [Apartment::class, Villa::class, Floor::class, FurnishedApartment::class, FurnishedVilla::class, Studio::class], function (Builder $query) use ($request) {
                    $query->where('car_entrance', $request->car_entrance);
                });
            })
            ->when($request->has('floor_number'), function ($query) use ($request) {
                $query->whereHasMorph('adable', [Apartment::class, Villa::class, Studio::class], function (Builder $query) use ($request) {
                    $query->where('floor_number', $request->floor_number);
                });
            })
            ->when($request->has('air_conditioner'), function ($query) use ($request) {
                $query->whereHasMorph('adable', [Apartment::class, Villa::class, Floor::class, FurnishedApartment::class, FurnishedVilla::class, Studio::class], function (Builder $query) use ($request) {
                    $query->where('air_conditioner', $request->air_conditioner);
                });
            })
            ->when($request->has('private_roof'), function ($query) use ($request) {
                $query->whereHasMorph('adable', [Apartment::class, Villa::class, FurnishedApartment::class, Studio::class], function (Builder $query) use ($request) {
                    $query->where('private_roof', $request->private_roof);
                });
            })
            ->when($request->has('in_villa'), function ($query) use ($request) {
                $query->whereHasMorph('adable', [Apartment::class, Villa::class, Floor::class, FurnishedApartment::class, Studio::class], function (Builder $query) use ($request) {
                    $query->where('in_villa', $request->in_villa);
                });
            })
            ->when($request->has('two_entrance'), function ($query) use ($request) {
                $query->whereHasMorph('adable', [Apartment::class, Villa::class, Floor::class, FurnishedApartment::class, Studio::class], function (Builder $query) use ($request) {
                    $query->where('two_entrance', $request->two_entrance);
                });
            })
            ->when($request->has('private_entrance'), function ($query) use ($request) {
                $query->whereHasMorph('adable', [Apartment::class, Villa::class, Floor::class, FurnishedApartment::class, Studio::class], function (Builder $query) use ($request) {
                    $query->where('private_entrance', $request->private_entrance);
                });
            })
            ->when($request->has('street_width'), function ($query) use ($request) {
                $query->whereHasMorph('adable', [Land::class, Villa::class, Building::class, Shop::class, House::class, Rest::class, CommercialOffice::class, Warehouse::class, FurnishedVilla::class], function (Builder $query) use ($request) {
                    $query->where('street_width', $request->street_width);
                });
            })
            ->when($request->has('interface'), function ($query) use ($request) {
                $query->whereHasMorph('adable', [Land::class, Villa::class, Building::class, Shop::class, House::class, Rest::class, Farm::class, CommercialOffice::class, FurnishedVilla::class], function (Builder $query) use ($request) {
                    $query->where('interface', $request->interface);
                });
            })
            ->when($request->has('living_room_stairs'), function ($query) use ($request) {
                $query->whereHasMorph('adable', [Villa::class, FurnishedVilla::class], function (Builder $query) use ($request) {
                    $query->where('living_room_stairs', $request->living_room_stairs);
                });
            })
            ->when($request->has('number_of_apartments'), function ($query) use ($request) {
                $query->whereHasMorph('adable', [Villa::class, Building::class], function (Builder $query) use ($request) {
                    $query->where('number_of_apartments', $request->number_of_apartments);
                });
            })
            ->when($request->has('number_of_living_rooms'), function ($query) use ($request) {
                $query->whereHasMorph('adable', [Apartment::class, Villa::class, Floor::class, House::class, FurnishedApartment::class, FurnishedVilla::class, Studio::class], function (Builder $query) use ($request) {
                    $query->where('number_of_living_rooms', $request->number_of_living_rooms);
                });
            })
            ->when($request->has('maid_room'), function ($query) use ($request) {
                $query->whereHasMorph('adable', [Villa::class, FurnishedVilla::class], function (Builder $query) use ($request) {
                    $query->where('maid_room', $request->maid_room);
                });
            })
            ->when($request->has('driver_room'), function ($query) use ($request) {
                $query->whereHasMorph('adable', [Villa::class, FurnishedVilla::class], function (Builder $query) use ($request) {
                    $query->where('driver_room', $request->driver_room);
                });
            })
            ->when($request->has('swimming_pool'), function ($query) use ($request) {
                $query->whereHasMorph('adable', [Villa::class, Rest::class, Chalet::class, FurnishedVilla::class], function (Builder $query) use ($request) {
                    $query->where('swimming_pool', $request->swimming_pool);
                });
            })
            ->when($request->has('kitchen'), function ($query) use ($request) {
                $query->whereHasMorph('adable', [Villa::class, Rest::class, Room::class, Chalet::class, FurnishedVilla::class], function (Builder $query) use ($request) {
                    $query->where('kitchen', $request->kitchen);
                });
            })
            ->when($request->has('duplex'), function ($query) use ($request) {
                $query->whereHasMorph('adable', [Villa::class, FurnishedVilla::class], function (Builder $query) use ($request) {
                    $query->where('duplex', $request->duplex);
                });
            })
            ->when($request->has('basement'), function ($query) use ($request) {
                $query->whereHasMorph('adable', [Villa::class, FurnishedVilla::class], function (Builder $query) use ($request) {
                    $query->where('basement', $request->basement);
                });
            })
            ->when($request->has('floor_number'), function ($query) use ($request) {
                $query->whereHasMorph('adable', [Floor::class, FurnishedApartment::class], function (Builder $query) use ($request) {
                    $query->where('floor_number', $request->floor_number);
                });
            })
            ->when($request->has('number_of_shops'), function ($query) use ($request) {
                $query->whereHasMorph('adable', [Building::class], function (Builder $query) use ($request) {
                    $query->where('number_of_shops', $request->number_of_shops);
                });
            })
            ->when($request->has('family_area'), function ($query) use ($request) {
                $query->whereHasMorph('adable', [Rest::class], function (Builder $query) use ($request) {
                    $query->where('family_area', $request->family_area);
                });
            })
            ->when($request->has('football_field'), function ($query) use ($request) {
                $query->whereHasMorph('adable', [Rest::class, Chalet::class], function (Builder $query) use ($request) {
                    $query->where('football_field', $request->football_field);
                });
            })
            ->when($request->has('volleyball_field'), function ($query) use ($request) {
                $query->whereHasMorph('adable', [Rest::class, Chalet::class], function (Builder $query) use ($request) {
                    $query->where('volleyball_field', $request->volleyball_field);
                });
            })
            ->when($request->has('amusement_park_games'), function ($query) use ($request) {
                $query->whereHasMorph('adable', [Rest::class, Chalet::class], function (Builder $query) use ($request) {
                    $query->where('amusement_park_games', $request->amusement_park_games);
                });
            })
            ->when($request->has('renting_duration'), function ($query) use ($request) {
                $query->whereHasMorph('adable', [Camp::class, Room::class, FurnishedApartment::class, Studio::class], function (Builder $query) use ($request) {
                    $query->where('renting_duration', $request->renting_duration);
                });
            })
            ->when($request->has('attachment'), function ($query) use ($request) {
                $query->whereHasMorph('adable', [FurnishedApartment::class], function (Builder $query) use ($request) {
                    $query->where('attachment', $request->attachment);
                });
            })
            ->when($request->has('family_area'), function ($query) use ($request) {
                $query->whereHasMorph('adable', [Chalet::class], function (Builder $query) use ($request) {
                    $query->where('family_area', $request->family_area);
                });
            })
            ->when(!$request->has('no_pagination'), function ($query) {
                return $query->paginate(6);
            }, function ($query) {
                return $query->get();
            });
        // ->paginate(6);

        $ads_data = AdResource::collection($ads)->response()->getData(true);
        return $this->returnData('data', $ads_data);
    }


    public function show($id)
    {
        $ad = Ad::find($id);
        if ($ad && $ad->is_active ==  1) {
            $ads_data = new AdResource($ad);
            $ad->increment('views_count');


            return $this->returnData('data', $ads_data);
        } else {
            return $this->returnError('404', __('site.not found.'));
        }
    }

    public function store(AdRequest $request)
    {


        try {
            DB::beginTransaction();
            $category = Category::find($request->category_id);
            $ad_data = $request->only([
                'for_rent', 'category_id', 'license_number', 'price', 'currency_id', 'area', 'length', 'width', 'advertiser_relationship_with_property', 'description', 'map_latitude', 'map_longitude', 'property_age', 'neighborhood_id', 'renting_duration'
            ]);

            $ad_data['user_id'] = auth('api')->user()->id;
            $ad_data['adable_type'] = $category->adable;
            $ad =  Ad::create($ad_data);


            $adable = $category->adable
                ::create($request->except([
                    'for_rent', 'category_id', 'license_number', 'price', 'currency_id', 'area', 'length', 'width', 'advertiser_relationship_with_property', 'description', 'map_latitude', 'map_longitude', 'property_age',
                    'files', 'neighborhood_id', 'renting_duration'
                ]));

            $ad->update(['adable_id' => $adable->id]);

            if ($request->has('files')) {
                foreach ($request['files'] as $fileData) {
                    // $file = $fileData['path'];
                    // $fileObject = $request->file($file); // Get the file object

                    // Check if a file was uploaded
                    // return
                    // $fileData;
                    if ($fileData) {
                        $file = $this->upload_base64($fileData['path'], 'files');
                        File::create([
                            'path' => $file,
                            'description' => $fileData['description'],
                            'ad_id' => $ad->id
                        ]);
                    }
                }
            } else {
                File::create([
                    'path' => 'public/storage/files/default.png',
                    'description' =>null,
                    'ad_id' => $ad->id
                ]);
            }

            DB::commit();   
        } catch (\Exception $e) {
            DB::rollBack();
            return $this->returnError('', $e->getMessage());
        }
        return $this->returnSuccessMassage(__('dashboard.added_successfully'));
    }



    public function update(AdRequest $request, $id)
    {
        $ad = Ad::find($id);
        if ($ad) {
            // Update Ad
            $ad->update($request->only([
                'for_rent', 'category_id', 'license_number', 'price', 'currency_id', 'area', 'length', 'width', 'advertiser_relationship_with_property', 'description', 'map_latitude', 'map_longitude', 'property_age'
            ]));

            $category = Category::find($request->category_id);
            $adable = $category->adable
                ::update($request->except([
                    'for_rent', 'category_id', 'license_number', 'price', 'currency_id', 'area', 'length', 'width', 'advertiser_relationship_with_property', 'description', 'map_latitude', 'map_longitude', 'property_age', 'files'
                ]));

            return $this->returnSuccessMassage(__('site.ad general details upated successfully'));
        } else {
            return $this->returnError('404', __('dashboard.not found.'));
        }
    }


    public function destroy($id)
    {
        $ad = Ad::find($id);
        if ($ad) {

            $ad->delete();
            $ad->adable->delete();
            return $this->returnSuccessMassage(__('dashboard.deleted_successfully'));
        } else {
            return $this->returnError('404', __('dashboard.not_found'));
        }
    }

    public function report(ReportAdRequest $request)
    {
        $user_id = auth()->guard('api')->user()->id;
        Report::create([
            'user_id' => $user_id,
            'ad_id' => $request->ad_id,
            'reason' => $request->reason
        ]);
        return $this->returnSuccessMassage(__('dashboard.reported_successfully'));
    }
}
