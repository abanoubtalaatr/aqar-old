<?php

namespace App\Http\Controllers\Api\Mobile;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\Mobile\BankTransferRequest;
use App\Models\BankTransfer;
use App\Traits\GeneralTrait;
use Illuminate\Http\Request;

class BankTransferController extends Controller
{
    use GeneralTrait;

    public function store(BankTransferRequest $request){

        $data = $request->input();
        if($request->hasFile('image')){
            $data['image']=$this->upload_file($request['image'],'bank_transfers');
        }
        BankTransfer::create($data);
        return $this->returnSuccessMassage(__('site.recored created successfully.'));
        
    }
}
