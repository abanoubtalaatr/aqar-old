<?php

namespace App\Http\Controllers\Api\Mobile;

use App\Http\Controllers\Controller;
use App\Http\Resources\PageResource;
use App\Models\Page;
use App\Traits\GeneralTrait;
use Illuminate\Http\Request;

class PageController extends Controller
{
    use GeneralTrait ;
    public function index()
    {
        $pages = Page::get();
        $pages_data = PageResource::collection($pages);
        return $this->returnData('data', $pages_data);
    }
    public function show(Page $page)
    {
        $page_date = new PageResource($page);
        return $this->returnData('data', $page_date);
    }

    public function terms()
    {
        $terms = Page::where('key', 'terms_and_conditions')->first();
        $data = new PageResource($terms);
        return $this->returnData('terms', $data);
    }
}
