<?php

namespace App\Http\Controllers\Api\Mobile;

use App\Models\File;
use App\Models\Order;
use App\Models\Category;
use App\Traits\GeneralTrait;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\Api\Mobile\OrderRequest;
use App\Http\Resources\Mobile\AdResource;
use App\Http\Resources\Mobile\OrderResource;

class OrderController extends Controller
{
    use GeneralTrait;
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $orders = Order::where('user_id', auth('api')->user()->id)->orderBy('created_at', 'desc')->paginate(6);
        $orders_data = OrderResource::collection($orders)->response()->getData(true);
        return $this->returnData('data', $orders_data);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(OrderRequest $request)
    {
        $category = Category::find($request->category_id);
        // return $category;
        $order_data = $request->only(['for_rent','neighborhood_id', 'category_id','property_age', 'meter_price', 'price_from', 'price_to', 'currency_id', 'area_from', 'area_to', 'description', 'map_latitude', 'map_longitude', 'has_files']);

        $order_data['user_id'] = auth('api')->user()->id;
        $order_data['orderable_type'] = $category->adable;
        $order =  Order::create($order_data);


        $orderable = $category->adable
            ::create($request->except([
                'for_rent', 'category_id', 'user_id', 'meter_price', 'neighborhood_id','property_age','price_from', 'price_to', 'currency_id', 'area_from', 'area_to', 'description', 'map_latitude', 'map_longitude','has_files', 'files'
            ]));

        $order->update(['orderable_id' => $orderable->id]);

        if ($request->has('files')) {
            foreach ($request['files'] as $i) {
                $file = $this->upload_file($i['path'], 'files');
                File::create([
                    'path' => $file,
                    'description' => $i['description'],
                    'order_id' => $order->id
                ]);
            }
        }
        return $this->returnSuccessMassage(__('dashboard.added_successfully'));
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $order = Order::find($id);
        if ($order) {
            $orders_data = new AdResource($order);
            return $this->returnData('data', $orders_data);
        } else {
            return $this->returnError('404', __('site.not found.'));
        }
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $order = Order::find($id);
        if ($order) {

            $order->delete();
            $order->orderable->delete();
            return $this->returnSuccessMassage(__('dashboard.deleted_successfully'));
        } else {
            return $this->returnError('404', __('dashboard.not_found'));
        }
    }
}
