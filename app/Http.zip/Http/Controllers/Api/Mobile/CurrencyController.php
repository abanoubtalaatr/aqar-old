<?php

namespace App\Http\Controllers\Api\Mobile;

use App\Http\Controllers\Controller;
use App\Http\Resources\Mobile\CurrencyResource;
use App\Models\Currency;
use App\Traits\GeneralTrait;
use Illuminate\Http\Request;

class CurrencyController extends Controller
{

    use GeneralTrait;
    public function index()
    {
        $currencies = Currency::get();
        $currencies_data = CurrencyResource::collection($currencies);
        return $this->returnData('data', $currencies_data);
    }
}
