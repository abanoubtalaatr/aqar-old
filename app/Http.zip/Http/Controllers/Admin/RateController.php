<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Rate;
use Illuminate\Http\Request;

class RateController extends Controller
{
    public function __construct()
    {
        $this->middleware('permission:rates-read')->only('index', 'show');
        $this->middleware('permission:rates-delete')->only('destroy');
    }


    public function index()
    {
        $unseen_rates = Rate::where('seen', 0)->get();
        // foreach()
        // $unseen_rates->update(['seen',1]);
        $rates = Rate::paginate(20);
        return view('admin.rates.index', compact('rates'));
    }

    public function destroy($id)
    {
        $rate = Rate::find($id);
        $rate->delete();
        return $id;
    }

    //=========================delete all==================
    public function delete_all(Request $request)
    {
        $icons = Rate::whereIn('id', $request['ids'])->pluck('avatar');
        $this->remove_all($icons);
        Rate::whereIn('id', $request['ids'])->delete();
        return "success";
    }
}
