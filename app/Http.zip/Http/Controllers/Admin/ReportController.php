<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Report;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ReportController extends Controller
{
    public function __construct()
    {
        $this->middleware('permission:reports-read')->only('index', 'show');
        $this->middleware('permission:reports-delete')->only('destroy');

    }
   
    public function index()
    {
        $reports=Report::paginate(20);
        return view('admin.reports.index',compact('reports'));
    }

    public function show($id)
    {          
        $report =Report::find($id);
        if($report){
            $report->update(['seen'=>1]);
          return view ('admin.reports.show',compact('report'));
        }else{
            return redirect()->back()->with(["error"=>__('dashboard.not found.')]);
        }
    }

   
    public function destroy($id)
    {
         $report=Report::find($id)->delete();
         return "success";
    }

      //=========================delete all==================
      public function delete_all(Request $request){
        report::whereIn('id',$request['ids'])->delete();
        return "success";
    }

    //=========================seen====================
    public function seen($id){
        $report=Report::find($id);
        $report->update(['seen'=>1]);
        return redirect()->back()->with(["success"=>__('dashboard.recored updated successfully.')]);
    }
}
