<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\UserRequest;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class ProfileController extends Controller
{
    public function __construct()
    {
        $this->middleware('permission:profile-read')->only('index', 'show');
        $this->middleware('permission:profile-update')->only('edit','update');
    }
    public function profile()
    {
        if (request()->has('not')) {
            $not = Auth::user()->unreadNotifications->where('id', request('not'))->first();
            if ($not) {
                $not->markAsRead();
            }
        }
        $user = auth()->user();
        return view('admin.users.show', compact('user'));
    }


    public function edit()
    {
        //   return  Auth::user()->getAuthPassword();
        $user = auth()->user();
        return view('admin.profile.update', compact('user'));
    }

    public function update(UserRequest $request)
    {
        $user_id = auth()->user()->id;
        $user = User::find($user_id);

        $data = $request->except(['user_id', 'password_confirmation', 'role']);
        if ($request->hasFile('avatar')) {
            $user->avatar ? $this->remove_file($user->avatar) : '';
            $data['avatar'] = $this->upload_file($request['avatar'], 'users');
        }
        $user->update($data);
        return redirect('profile')->with(["success" => __('dashboard.recored updated successfully.')]);
    }
}
