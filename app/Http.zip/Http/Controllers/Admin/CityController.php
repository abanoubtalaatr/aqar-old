<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\CityRequest;
use App\Models\City;
use App\Models\Country;
use Illuminate\Http\Request;
use PHPUnit\Framework\Constraint\Count;

class CityController extends Controller
{
    public function __construct()
    {
        $this->middleware('permission:cities-read')->only('index', 'show');
        $this->middleware('permission:cities-create')->only('create', 'store');
        $this->middleware('permission:cities-update')->only('edit','update');
        $this->middleware('permission:cities-delete')->only('destroy');
    }

    public function index(Request $request){
        $country = Country::find($request->country_id) ;
        $cities = City::where('country_id',$request->country_id)->paginate(20);
        return view('admin.cities.index',compact('cities','country'));
    }

    public function create(Request $request)
    {
        $country_id = $request->country_id ;
        $countries = Country::get();
        return view('admin.cities.create',compact('countries','country_id'));
    }

    public function store(CityRequest $request)
    {
        City::create($request->validated());
        return to_route('cities.index',['country_id'=>$request->country_id])->with(["success" => __('dashboard.recored created successfully.')]);
    }


    public function edit(City $city)
    {
        $countries = Country::get();
        return view('admin.cities.update', compact('city','countries'));
    }


    public function update(CityRequest $request, City $city)
    {

        $city->update($request->validated());
        return to_route('cities.index',['country_id'=>$city->country_id])->with(["success" => __('dashboard.recored updated successfully.')]);
    }


    public function destroy($id)
    {
        $city = City::find($id)->delete();
        return "success";
    }

    //=========================delete all==================
    public function delete_all(Request $request)
    {
        City::whereIn('id', $request['ids'])->delete();
        return "success";
    }
}
