<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Page;
use App\Http\Requests\Admin\PageRequest;

class PageController extends Controller
{
    public function __construct()
    {
        $this->middleware('permission:pages-read')->only('index', 'show');
        $this->middleware('permission:pages-create')->only('create', 'store');
        $this->middleware('permission:pages-update')->only('edit','update');
        $this->middleware('permission:pages-delete')->only('destroy');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $pages = Page::get();
        return view('admin.pages.index', compact('pages'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.pages.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(PageRequest $request)
    {
        Page::create($request->input());
        return redirect()->route('pages.index')->with(["success" => __('dashboard.recored created successfully.')]);
    }


    public function edit(Page $page)
    {
        return view('admin.pages.update', compact('page'));
    }


    public function update(PageRequest $request, Page $page)
    {

        $page->update($request->input());
        return redirect()->route('pages.index')->with(["success" => __('dashboard.recored updated successfully.')]);
    }


    public function destroy($id)
    {
        $page = Page::find($id)->delete();
        return "success";
    }

    //=========================delete all==================
    public function delete_all(Request $request)
    {
        Page::whereIn('id', $request['ids'])->delete();
        return "success";
    }
}
