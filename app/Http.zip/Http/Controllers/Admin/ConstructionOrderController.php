<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ConstructionOrder;
use Illuminate\Http\Request;

class ConstructionOrderController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $constructions=ConstructionOrder::paginate(15);
        ConstructionOrder::where('seen', 0)->update(['seen'=> 1]);

        return view('admin.construction_orders.index',compact('constructions'));
    }




    public function show(ConstructionOrder $construction)
    {
        return view('admin.construction_orders.show', compact('construction'));
    }


}
