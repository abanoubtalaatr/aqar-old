<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Role;
use App\Models\Permission;
use Auth;

class RoleController extends Controller
{
    public function __construct()
    {
        $this->middleware('permission:roles-read')->only('index', 'show');
        $this->middleware('permission:roles-create')->only('create', 'store');
        $this->middleware('permission:roles-update')->only('edit','update');
        $this->middleware('permission:roles-delete')->only('destroy');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $roles = Role::get();
        return view('admin.roles.index', compact('roles'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        return view('admin.roles.create');
    }

    public function store(Request $request)
    {
        //
        $request->validate([
            'name' => 'required|unique:roles|max:255',
        ]);

        $role = Role::create($request->input());
        return redirect('roles')->with(["success" => __('dashboard.recored created successfully.')]);
    }


    public function edit(Role $role)
    {
        return view('admin.roles.update', compact('role'));
    }


    public function update(Request $request, Role $role)
    {
        $request->validate([
            'name' => 'required|unique:roles,name,' . $role->id . '|max:255',
        ]);

        $role->update($request->input());
        return redirect('roles')->with(["success" => __('dashboard.recored updated successfully.')]);
    }


    public function destroy(Role $role)
    {
        //
        $role->delete();
        return "success";
    }

    //=========================delete all==================
    public function delete_all(Request $request)
    {
        Role::whereIn('id', $request['ids'])->delete();
        return "success";
    }

    //=======================permission====================
    public function permission($id)
    {
        $permissions = Permission::get();
        $role = Role::find($id);
        return view('admin.roles.permission', compact('role', 'permissions'));
    }

    public function attach_permissions(Request $request, $id)
    {
        $role = Role::find($id);
        $allPermission = Permission::get();
        $role->removePermissions($allPermission);
        if (!empty($request->permission) && count($request->permission) > 0) {
            $permission = Permission::whereIn('id', $request->permission)->get();
            $role->givePermissions($permission);
        }
        return redirect()->back()->with(["success" => __('dashboard.recored updated successfully.')]);
    }
}
