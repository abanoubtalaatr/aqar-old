<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\CurrencyRequest;
use App\Models\Currency;
use Illuminate\Http\Request;

class CurrencyController extends Controller
{
    public function __construct()
    {
        $this->middleware('permission:currencies-read')->only('index', 'show');
        $this->middleware('permission:currencies-create')->only('create', 'store');
        $this->middleware('permission:currencies-update')->only('edit','update');
        $this->middleware('permission:currencies-delete')->only('destroy');
    }
    public function index()
    {
        // return "f";
        $currencies = Currency::paginate(10);
        return view('admin.currencies.index', compact('currencies'));
    }

    public function create()
    {
        return view('admin.currencies.create');
    }

    public function store(CurrencyRequest $request)
    {
        Currency::create($request->validated());
        return redirect(route('currencies.index'))->with([
            'success' => __('dashboard.created_successfulley')
        ]);
    }

    public function edit(Currency $currency)
    {
        return view('admin.currencies.edit', compact('currency'));
    }

    public function update(CurrencyRequest $request, Currency $currency)
    {
        $currency->update($request->input());
        return redirect(route('currencies.index'))->with([
            'success' => __('dashboard.updated_successfulley')
        ]);
    }

    public function destroy(Currency $currency)
    {
        $currency->delete();
        return 'success';
    }

    public function delete_all(Request $request)
    {
     
        Currency::whereIn('id', $request['ids'])->delete();
        return "success";
    }
}
