<?php

namespace App\Http\Requests\Api\Mobile;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Request;

class OrderRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(Request $request): array
    {
        $additional_data = [];

        $data = [

            // Basic Info :
            'for_rent' => 'required|in:0,1,2',
            'category_id' => 'required|exists:categories,id',
            // 'user_id' => 'required|exists:users,id',
            'meter_price' => 'nullable|integer',
            'price_from' => 'required|integer',
            'price_to' => 'required|integer',
            'currency_id' => 'required|exists:currencies,id',
            'area_from' => 'required|integer',
            'area_to' => 'required|integer',
            'property_age' => 'required|integer',
            'description' => 'required|string',
            'map_latitude' => 'required',
            'map_longitude' => 'required',
            'has_files' => 'nullable|boolean',

        ];


        if ($request->category_id == 1) {
            $additional_data = [

                'number_of_rooms' => 'required|integer',
                'number_of_living_rooms' => 'required|integer',
                'number_of_bathrooms' => 'required|integer',
                'floor_number' => 'required|integer',
                'furnished' => 'nullable|boolean',
'families_or_singles' => 'nullable|in:0,1,2',                'two_entrance' => 'nullable|boolean',
                'in_villa' => 'nullable|boolean',
                'air_conditioner' => 'nullable|boolean',
                'car_entrance' => 'nullable|boolean',
                'private_entrance' => 'nullable|boolean',

            ];
        } elseif ($request->category_id == 2) {
            $additional_data = [
                'Interface' => 'nullable|in: 
                0, 1, 2, 3,
                4, 5, 6, 7, 8, 9',
                'street_width' => 'required|integer',
            ];
        } elseif ($request->category_id == 3) {
            $additional_data = [
                'Interface' => 'nullable|in: 
                0, 1, 2, 3,
                4, 5, 6, 7, 8, 9',
                'street_width' => 'required|integer',
                'number_of_rooms' => 'required|integer',
                'number_of_apartments' => 'required|integer',
                'number_of_living_rooms' => 'required|integer',
                'number_of_bathrooms' => 'required|integer',


                // additional
                'kitchen' => 'nullable|boolean',
                'furnished' => 'quired|in:0,1',
                'driver_room' => 'nullable|boolean',
                'air_conditioner' => 'nullable|boolean',
                'maid_room' => 'quired|in:0,1',
                'swimming_pool' => 'quired|in:0,1',
                'car_entrance' => 'rquired|in:0,1',
                'basement' => 'rquired|in:0,1',
                'living_room_stairs' => 're quired|in:0,1',

            ];
        } elseif ($request->category_id == 4) {
            $additional_data = [

                'number_of_rooms' => 'required|integer',
                'number_of_living_rooms' => 'required|integer',
                'number_of_bathrooms' => 'required|integer',

                'floor_number' => 'required|integer',


                // additional
                'air_conditioner' => 'nullable|boolean',
                'car_entrance' => 'nullable|boolean',
                'in_villa' => 'nullable|boolean',
                'two_entrance' => 'nullable|boolean',
                'private_entrance' => 'nullable|boolean',
            ];
        } elseif ($request->category_id == 5) {
            $additional_data = [
                'Interface' => 'nullable|in: 
                0, 1, 2, 3,
                4, 5, 6, 7, 8, 9',
                'street_width' => 'required|integer',
                'number_of_apartment' => 'required|integer',
                'number_of_shops' => 'required|integer',

            ];
        } elseif ($request->category_id == 6) {
            $additional_data = [

                'street_width' => 'required|integer',
            ];
        } elseif ($request->category_id == 7) {
            $additional_data = [
                'Interface' => 'nullable|in: 
                0, 1, 2, 3,
                4, 5, 6, 7, 8, 9',

                'street_width' => 'required|integer',
                'number_of_rooms' => 'required|integer',
                'number_of_living_rooms' => 'required|integer',



                // additional
               
                'furnished' => 'nullable|boolean',
            ];
        } elseif ($request->category_id == 8) {
            $additional_data = [

                'kitchen' => 'nullable|boolean',
                'families_or_singles' => 'nullable|in:0,1,2',

            ];
        } elseif ($request->category_id == 9) {
            $additional_data = [

                'families_or_singles' => 'nullable|in:0,1,2',
                'street_width' => 'required|integer',
                'kitchen' => 'nullable|boolean',
            ];
        } elseif ($request->category_id == 10) {
            $additional_data = [

                'street_width' => 'required|integer',
                'furnished' => 'nullable|boolean',
            ];
        } elseif ($request->category_id == 11) {
            $additional_data = [

                'street_width' => 'required|integer',

            ];
        } elseif ($request->category_id == 12) {
            $additional_data = [
                'renting_duration' => 'nullable|in:0, 1, 2',

                // additional
                'family_area' => 'nullable|boolean',

            ];
        } elseif ($request->category_id == 13) {
            $additional_data = [
                'renting_duration' => 'nullable|in:0, 1, 2',

                // additional
                'kitchen' => 'nullable|boolean',
            ];
        } elseif ($request->category_id == 14) {
            $additional_data = [
                'number_of_rooms' => 'required|integer',
                'floor_number' => 'required|integer',
                'number_of_living_rooms' => 'required|integer',
                'number_of_bathrooms' => 'required|integer',


                // additional
                'furnished' => 'nullable|boolean',
                'private_entrance' => 'nullable|boolean',
                'two_entrance' => 'nullable|boolean',
                'in_villa' => 'nullable|boolean',
                'air_conditioner' => 'nullable|boolean',
                'families_or_singles' => 'nullable|in:0,1,2',
                'private_roof' => 'nullable|boolean',
            ];
        } elseif ($request->category_id == 15) {
            $additional_data = [


                // additional
                'kitchen' => 'nullable|boolean',
                'pool' => 'nullable|boolean',
                'families_or_singles' => 'nullable|in:0,1,2',
                'football_field' => 'nullable|boolean',
                'volleyball_field' => 'nullable|boolean',
                'amusement_park_games' => 'nullable|boolean',
                'family_area' => 'nullable|boolean',
            ];
        } elseif ($request->category_id == 16) {
            $additional_data = [



                'number_of_living_rooms' => 'required|integer',

                'renting_duration' => 'nullable|in: daily, mounthly, yearly',
                'floor_number' => 'required|integer',

                // additional

                'families_or_singles' => 'nullable|in:0,1,2',




                'furnished' => 'nullable|boolean',
                'kitchen' => 'nullable|boolean',
                'private_roof' => 'nullable|boolean',
                'in_villa' => 'nullable|boolean',
                'two_entrance' => 'nullable|boolean',
                'private_entrance' => 'nullable|boolean',
                'air_conditioner' => 'nullable|boolean',
                'attachment' => 'nullable|boolean',
                'car_entrance' => 'nullable|boolean',
            ];
        } elseif ($request->category_id == 17) {
            $additional_data = [
                'Interface' => 'nullable|in: 
                0, 1, 2, 3,
                4, 5, 6, 7, 8, 9',

                'street_width' => 'required|integer',
                'number_of_rooms' => 'required|integer',
                'number_of_living_rooms' => 'required|integer',
                'number_of_bathrooms' => 'required|integer',


                // additional
                'kitchen' => 'nullable|boolean',
                'amusement_park_games' => 'nullable|boolean',
                'air_conditioner' => 'nullable|boolean',
                'driver_room' => 'nullable|boolean',
                'maid_room' => 'nullable|boolean',
                'swimming_pool' => 'nullable|boolean',
                'attachment' => 'nullable|boolean',
                'basement' => 'nullable|boolean',
                'living_room_stairs' => 'nullable|boolean',

                'duplex' => 'nullable|boolean',
            ];
        } elseif ($request->category_id == 18) {
            $additional_data = [
                
            ];
        }

        return array_merge($data, $additional_data);
    }
}
