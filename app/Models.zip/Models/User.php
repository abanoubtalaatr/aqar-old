<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\Hash;
use Laravel\Sanctum\HasApiTokens;
use Laratrust\Contracts\LaratrustUser;
use Laratrust\Traits\HasRolesAndPermissions;
use Tymon\JWTAuth\Contracts\JWTSubject;
use Tymon\JWTAuth\Facades\JWTAuth;

class User extends Authenticatable implements JWTSubject, LaratrustUser
{

    use HasRolesAndPermissions;

    use HasApiTokens, HasFactory, Notifiable;
    protected $guarded = [];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];


    // ==============JWT=======================

    public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    /**
     * Return a key value array, containing any custom claims to be added to the JWT.
     *
     * @return array
     */
    public function getJWTCustomClaims()
    {
        return [];
    }

    public function token()
    {
        return JWTAuth::fromUser($this);
    }

    // ====================Mutators===================
    public function setPasswordAttribute($val)
    {
        $this->attributes['password'] = Hash::make($val);
    }

    // =========================Scopes===============================

    public  function scopeActive($query)
    {
        return $query->where('active', 1);
    }
    //==================================================================


    public function favourites()
    {
        return $this->belongsToMany(Ad::class, 'favourites', 'user_id', 'ad_id');
    }

    public function alreadyFavourite($ad_id)
    {
        return self::favourites()->where('ad_id', $ad_id)->exists();
    }

    public function getGenderAttribute($val)
    {
        if ($val == '0') {
            return $val = 'man';
        } else {
            return $val = 'woman';
        }
    }

    public function getRateAttribute()
    {
        $r = 0;
        foreach ($this->rates as $rate) {
            $r += $rate->rate;
        }
        if ($this->rates->count() > 0) {
            $r = round($r / $this->rates->count());
        }
        return $r;
    }

    public function getCurrentRateAttribute()
    {
        if (auth()->guard('api')->check()) {
            $rater_id = auth()->guard('api')->user()->id;
            $rate = UserRate::where([
                'rater_id' => $rater_id,
                'user_id' => $this->id
            ])->first();
            return $rate ?  $rate->rate : 0;
        } else {
            return 0;
        }
    }

    public function followers()
    {
        return $this->hasMany(Follower::class);
    }

    //============================= For Rating Users =============================
    public function rates()
    {
        return $this->hasMany(UserRate::class);
    }

    public function alreadyRate($user_id)
    {
        return self::rates()->where('user_id', $user_id)->exists();
    }
    //==========================================================
    public function ads()
    {
        return $this->hasMany(Ad::class);
    }

    
}
