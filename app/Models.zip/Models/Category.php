<?php

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    protected $guarded = [];
    protected $table = 'categories';
    public $timestamps = true;

    public function getNameAttribute()
    {
        if (app()->getLocale() == 'en') {
            return $this->name_en;
        }
        return $this->name_ar;
    }

    public function keys()
    {
        return $this->hasMany(Key::class);
    }
}
