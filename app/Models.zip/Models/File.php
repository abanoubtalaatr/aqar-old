<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class File extends Model
{
    protected $table = 'files';
    public $timestamps = false;
    protected $guarded = [];
    public function ad()
    {
        return $this->belongsTo(Ad::class);
    }
    public function getTypeAttribute()
    {
        $extension =  pathinfo($this->path, PATHINFO_EXTENSION);
        $imageExtensions = [
            'jpg', 'jpeg', 'gif', 'png', 'bmp', 'svg', 'svgz',
            'cgm', 'djv', 'djvu', 'ico', 'ief', 'jpe', 'pbm', 'pgm', 'pnm', 'ppm',
            'ras', 'rgb', 'tif', 'tiff', 'wbmp', 'xbm', 'xpm', 'xwd', 'webp'
        ];
        if (in_array($extension, $imageExtensions)) {
            return 0;
        } else {
            // video
            return 1;
        }
    }
}
